"""Repository abstractions for data access."""

